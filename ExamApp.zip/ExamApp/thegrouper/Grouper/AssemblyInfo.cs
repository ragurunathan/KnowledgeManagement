using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("CodeVendor.Controls.Grouper() - Grouper Class")]
[assembly: AssemblyDescription("A special custom rounding GroupBox with many painting features.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CodeVendor")]
[assembly: AssemblyProduct("CodeVendor.Controls")]
[assembly: AssemblyCopyright("Copyright � 2005 CodeVendor, All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
