﻿namespace KnowledgeMatrix.Forms
{
    partial class MockTestHome
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MockTestHome));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pnlShanuGrid = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new CodeVendor.Controls.Grouper();
            this.groupBox3 = new CodeVendor.Controls.Grouper();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Last = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.Previous = new System.Windows.Forms.Button();
            this.First = new System.Windows.Forms.Button();
            this.richTextBoxPrintCtrl7 = new ExtendedRichTextBox.RichTextBoxPrintCtrl();
            this.richTextBoxPrintCtrl1 = new ExtendedRichTextBox.RichTextBoxPrintCtrl();
            this.richTextBoxPrintCtrl6 = new ExtendedRichTextBox.RichTextBoxPrintCtrl();
            this.richTextBoxPrintCtrl5 = new ExtendedRichTextBox.RichTextBoxPrintCtrl();
            this.richTextBoxPrintCtrl4 = new ExtendedRichTextBox.RichTextBoxPrintCtrl();
            this.label13 = new System.Windows.Forms.Label();
            this.Answer = new System.Windows.Forms.Label();
            this.checkboxPanel = new System.Windows.Forms.Panel();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.AnswerInfo = new CodeVendor.Controls.Grouper();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.radioPanel = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.userInfo = new CodeVendor.Controls.Grouper();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Complexity = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.grouper1 = new CodeVendor.Controls.Grouper();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label33 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.checkboxPanel.SuspendLayout();
            this.AnswerInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.radioPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.userInfo.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.grouper1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(933, 504);
            this.tabControl1.TabIndex = 9;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.pnlShanuGrid);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button8);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.label37);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(925, 473);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mock Test List";
            // 
            // pnlShanuGrid
            // 
            this.pnlShanuGrid.Location = new System.Drawing.Point(7, 56);
            this.pnlShanuGrid.Name = "pnlShanuGrid";
            this.pnlShanuGrid.Size = new System.Drawing.Size(904, 398);
            this.pnlShanuGrid.TabIndex = 30;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button6.Enabled = false;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Image = global::KnowledgeMatrix.Properties.Resources.QP_Generate_OMR_sheet;
            this.button6.Location = new System.Drawing.Point(826, 7);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 40);
            this.button6.TabIndex = 29;
            this.button6.Tag = "QuestionPaper";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button7.Enabled = false;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.Transparent;
            this.button7.Image = global::KnowledgeMatrix.Properties.Resources.QP_Generate_Answer;
            this.button7.Location = new System.Drawing.Point(760, 7);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(60, 40);
            this.button7.TabIndex = 28;
            this.button7.Tag = "QuestionPaper";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button8.Enabled = false;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.Transparent;
            this.button8.Image = global::KnowledgeMatrix.Properties.Resources.QP_Generate_Q___A;
            this.button8.Location = new System.Drawing.Point(693, 7);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 40);
            this.button8.TabIndex = 27;
            this.button8.Tag = "QuestionPaper";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button9.Enabled = false;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Image = global::KnowledgeMatrix.Properties.Resources.QP_Generate_Question;
            this.button9.Location = new System.Drawing.Point(627, 7);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(60, 40);
            this.button9.TabIndex = 26;
            this.button9.Tag = "QuestionPaper";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(296, 13);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(242, 25);
            this.label37.TabIndex = 25;
            this.label37.Text = "Mock Test Dashboard";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSalmon;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowCellToolTips = false;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.Size = new System.Drawing.Size(916, 419);
            this.dataGridView1.TabIndex = 24;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 419);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.txtName);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.userInfo);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(925, 473);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Mock Test";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(689, 19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(124, 16);
            this.label34.TabIndex = 26;
            this.label34.Text = "Name of student:";
            this.label34.Visible = false;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(687, 45);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(226, 21);
            this.txtName.TabIndex = 7;
            this.txtName.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Location = new System.Drawing.Point(683, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(235, 465);
            this.panel1.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(5, 11);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(148, 16);
            this.label21.TabIndex = 17;
            this.label21.Text = "Response Snapshot";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(3, 31);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.ShowCellToolTips = false;
            this.dataGridView2.ShowEditingIcon = false;
            this.dataGridView2.Size = new System.Drawing.Size(202, 423);
            this.dataGridView2.TabIndex = 25;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.groupBox2.BackgroundGradientColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.BackgroundGradientMode = CodeVendor.Controls.Grouper.GroupBoxGradientMode.BackwardDiagonal;
            this.groupBox2.BorderColor = System.Drawing.Color.DarkGray;
            this.groupBox2.BorderThickness = 1F;
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.richTextBoxPrintCtrl7);
            this.groupBox2.Controls.Add(this.richTextBoxPrintCtrl1);
            this.groupBox2.Controls.Add(this.richTextBoxPrintCtrl6);
            this.groupBox2.Controls.Add(this.richTextBoxPrintCtrl5);
            this.groupBox2.Controls.Add(this.richTextBoxPrintCtrl4);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.Answer);
            this.groupBox2.Controls.Add(this.checkboxPanel);
            this.groupBox2.Controls.Add(this.AnswerInfo);
            this.groupBox2.Controls.Add(this.linkLabel1);
            this.groupBox2.Controls.Add(this.radioPanel);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.CustomGroupBoxColor = System.Drawing.Color.White;
            this.groupBox2.GroupImage = null;
            this.groupBox2.GroupTitle = "";
            this.groupBox2.Location = new System.Drawing.Point(6, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(20);
            this.groupBox2.PaintGroupBox = false;
            this.groupBox2.RoundCorners = 10;
            this.groupBox2.ShadowColor = System.Drawing.Color.DarkGray;
            this.groupBox2.ShadowControl = false;
            this.groupBox2.ShadowThickness = 3;
            this.groupBox2.Size = new System.Drawing.Size(672, 387);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.groupBox3.BackgroundGradientColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox3.BackgroundGradientMode = CodeVendor.Controls.Grouper.GroupBoxGradientMode.BackwardDiagonal;
            this.groupBox3.BorderColor = System.Drawing.Color.Transparent;
            this.groupBox3.BorderThickness = 1F;
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.Last);
            this.groupBox3.Controls.Add(this.Next);
            this.groupBox3.Controls.Add(this.Previous);
            this.groupBox3.Controls.Add(this.First);
            this.groupBox3.CustomGroupBoxColor = System.Drawing.Color.White;
            this.groupBox3.GroupImage = null;
            this.groupBox3.GroupTitle = "";
            this.groupBox3.Location = new System.Drawing.Point(22, 301);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(20);
            this.groupBox3.PaintGroupBox = false;
            this.groupBox3.RoundCorners = 10;
            this.groupBox3.ShadowColor = System.Drawing.Color.White;
            this.groupBox3.ShadowControl = false;
            this.groupBox3.ShadowThickness = 3;
            this.groupBox3.Size = new System.Drawing.Size(628, 29);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = global::KnowledgeMatrix.Properties.Resources.Complete;
            this.button3.Location = new System.Drawing.Point(523, 6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 23);
            this.button3.TabIndex = 19;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = global::KnowledgeMatrix.Properties.Resources.skip;
            this.button2.Location = new System.Drawing.Point(314, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 23);
            this.button2.TabIndex = 18;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Last
            // 
            this.Last.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Last.Image = global::KnowledgeMatrix.Properties.Resources.Last;
            this.Last.Location = new System.Drawing.Point(418, 6);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(101, 23);
            this.Last.TabIndex = 16;
            this.Last.UseVisualStyleBackColor = true;
            this.Last.Click += new System.EventHandler(this.Last_Click);
            // 
            // Next
            // 
            this.Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Next.Image = global::KnowledgeMatrix.Properties.Resources.mark_for_review;
            this.Next.Location = new System.Drawing.Point(208, 6);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(101, 23);
            this.Next.TabIndex = 15;
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // Previous
            // 
            this.Previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Previous.Image = global::KnowledgeMatrix.Properties.Resources.Save___Cont;
            this.Previous.Location = new System.Drawing.Point(103, 6);
            this.Previous.Name = "Previous";
            this.Previous.Size = new System.Drawing.Size(101, 23);
            this.Previous.TabIndex = 14;
            this.Previous.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Previous.UseVisualStyleBackColor = true;
            this.Previous.Click += new System.EventHandler(this.Previous_Click);
            // 
            // First
            // 
            this.First.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.First.Image = global::KnowledgeMatrix.Properties.Resources.First;
            this.First.Location = new System.Drawing.Point(0, 6);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(101, 23);
            this.First.TabIndex = 13;
            this.First.UseVisualStyleBackColor = true;
            this.First.Click += new System.EventHandler(this.First_Click);
            // 
            // richTextBoxPrintCtrl7
            // 
            this.richTextBoxPrintCtrl7.BackColor = System.Drawing.Color.White;
            this.richTextBoxPrintCtrl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxPrintCtrl7.Location = new System.Drawing.Point(316, 231);
            this.richTextBoxPrintCtrl7.Name = "richTextBoxPrintCtrl7";
            this.richTextBoxPrintCtrl7.ReadOnly = true;
            this.richTextBoxPrintCtrl7.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBoxPrintCtrl7.Size = new System.Drawing.Size(330, 60);
            this.richTextBoxPrintCtrl7.TabIndex = 35;
            this.richTextBoxPrintCtrl7.Text = "";
            // 
            // richTextBoxPrintCtrl1
            // 
            this.richTextBoxPrintCtrl1.BackColor = System.Drawing.Color.White;
            this.richTextBoxPrintCtrl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxPrintCtrl1.Location = new System.Drawing.Point(22, 34);
            this.richTextBoxPrintCtrl1.Name = "richTextBoxPrintCtrl1";
            this.richTextBoxPrintCtrl1.ReadOnly = true;
            this.richTextBoxPrintCtrl1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBoxPrintCtrl1.Size = new System.Drawing.Size(230, 265);
            this.richTextBoxPrintCtrl1.TabIndex = 31;
            this.richTextBoxPrintCtrl1.Text = "";
            // 
            // richTextBoxPrintCtrl6
            // 
            this.richTextBoxPrintCtrl6.BackColor = System.Drawing.Color.White;
            this.richTextBoxPrintCtrl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxPrintCtrl6.Location = new System.Drawing.Point(317, 167);
            this.richTextBoxPrintCtrl6.Name = "richTextBoxPrintCtrl6";
            this.richTextBoxPrintCtrl6.ReadOnly = true;
            this.richTextBoxPrintCtrl6.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBoxPrintCtrl6.Size = new System.Drawing.Size(330, 60);
            this.richTextBoxPrintCtrl6.TabIndex = 34;
            this.richTextBoxPrintCtrl6.Text = "";
            // 
            // richTextBoxPrintCtrl5
            // 
            this.richTextBoxPrintCtrl5.BackColor = System.Drawing.Color.White;
            this.richTextBoxPrintCtrl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxPrintCtrl5.Location = new System.Drawing.Point(318, 103);
            this.richTextBoxPrintCtrl5.Name = "richTextBoxPrintCtrl5";
            this.richTextBoxPrintCtrl5.ReadOnly = true;
            this.richTextBoxPrintCtrl5.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBoxPrintCtrl5.Size = new System.Drawing.Size(330, 60);
            this.richTextBoxPrintCtrl5.TabIndex = 33;
            this.richTextBoxPrintCtrl5.Text = "";
            // 
            // richTextBoxPrintCtrl4
            // 
            this.richTextBoxPrintCtrl4.BackColor = System.Drawing.Color.White;
            this.richTextBoxPrintCtrl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxPrintCtrl4.Location = new System.Drawing.Point(317, 42);
            this.richTextBoxPrintCtrl4.Name = "richTextBoxPrintCtrl4";
            this.richTextBoxPrintCtrl4.ReadOnly = true;
            this.richTextBoxPrintCtrl4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.richTextBoxPrintCtrl4.Size = new System.Drawing.Size(330, 60);
            this.richTextBoxPrintCtrl4.TabIndex = 32;
            this.richTextBoxPrintCtrl4.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(274, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "Options:";
            // 
            // Answer
            // 
            this.Answer.AutoSize = true;
            this.Answer.Location = new System.Drawing.Point(296, 25);
            this.Answer.Name = "Answer";
            this.Answer.Size = new System.Drawing.Size(0, 15);
            this.Answer.TabIndex = 16;
            this.Answer.Visible = false;
            // 
            // checkboxPanel
            // 
            this.checkboxPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.checkboxPanel.Controls.Add(this.checkBox4);
            this.checkboxPanel.Controls.Add(this.checkBox3);
            this.checkboxPanel.Controls.Add(this.checkBox2);
            this.checkboxPanel.Controls.Add(this.checkBox1);
            this.checkboxPanel.Location = new System.Drawing.Point(264, 40);
            this.checkboxPanel.Name = "checkboxPanel";
            this.checkboxPanel.Size = new System.Drawing.Size(386, 261);
            this.checkboxPanel.TabIndex = 3;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoEllipsis = true;
            this.checkBox4.Location = new System.Drawing.Point(8, 170);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(30, 48);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoEllipsis = true;
            this.checkBox3.Location = new System.Drawing.Point(8, 108);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(29, 48);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoEllipsis = true;
            this.checkBox2.Location = new System.Drawing.Point(8, 55);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(30, 48);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoEllipsis = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.checkBox1.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.checkBox1.FlatAppearance.BorderSize = 5;
            this.checkBox1.Location = new System.Drawing.Point(8, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(31, 49);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "1";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // AnswerInfo
            // 
            this.AnswerInfo.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.AnswerInfo.BackgroundGradientColor = System.Drawing.Color.WhiteSmoke;
            this.AnswerInfo.BackgroundGradientMode = CodeVendor.Controls.Grouper.GroupBoxGradientMode.ForwardDiagonal;
            this.AnswerInfo.BorderColor = System.Drawing.Color.DarkGray;
            this.AnswerInfo.BorderThickness = 1F;
            this.AnswerInfo.Controls.Add(this.label5);
            this.AnswerInfo.Controls.Add(this.label4);
            this.AnswerInfo.Controls.Add(this.label3);
            this.AnswerInfo.Controls.Add(this.label2);
            this.AnswerInfo.Controls.Add(this.pictureBox4);
            this.AnswerInfo.Controls.Add(this.pictureBox3);
            this.AnswerInfo.Controls.Add(this.pictureBox2);
            this.AnswerInfo.Controls.Add(this.pictureBox1);
            this.AnswerInfo.Controls.Add(this.label23);
            this.AnswerInfo.CustomGroupBoxColor = System.Drawing.Color.White;
            this.AnswerInfo.GroupImage = null;
            this.AnswerInfo.GroupTitle = "";
            this.AnswerInfo.Location = new System.Drawing.Point(0, 328);
            this.AnswerInfo.Name = "AnswerInfo";
            this.AnswerInfo.Padding = new System.Windows.Forms.Padding(20);
            this.AnswerInfo.PaintGroupBox = false;
            this.AnswerInfo.RoundCorners = 10;
            this.AnswerInfo.ShadowColor = System.Drawing.Color.DarkGreen;
            this.AnswerInfo.ShadowControl = false;
            this.AnswerInfo.ShadowThickness = 3;
            this.AnswerInfo.Size = new System.Drawing.Size(672, 52);
            this.AnswerInfo.TabIndex = 11;
            this.AnswerInfo.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(457, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 15);
            this.label5.TabIndex = 34;
            this.label5.Text = "Mark for Review";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(328, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 33;
            this.label4.Text = "Skip";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(178, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 15);
            this.label3.TabIndex = 32;
            this.label3.Text = "Yet To Attend";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 31;
            this.label2.Text = "Completed";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(437, 27);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(15, 15);
            this.pictureBox4.TabIndex = 30;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(308, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(15, 15);
            this.pictureBox3.TabIndex = 29;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(158, 27);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(15, 15);
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(51, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(15, 15);
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(12, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 15);
            this.label23.TabIndex = 1;
            this.label23.Text = "Legend:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(11, 11);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(0, 15);
            this.linkLabel1.TabIndex = 5;
            // 
            // radioPanel
            // 
            this.radioPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.radioPanel.Controls.Add(this.pictureBox9);
            this.radioPanel.Controls.Add(this.pictureBox8);
            this.radioPanel.Controls.Add(this.pictureBox7);
            this.radioPanel.Controls.Add(this.pictureBox6);
            this.radioPanel.Controls.Add(this.radioButton4);
            this.radioPanel.Controls.Add(this.radioButton3);
            this.radioPanel.Controls.Add(this.radioButton2);
            this.radioPanel.Controls.Add(this.radioButton1);
            this.radioPanel.Location = new System.Drawing.Point(263, 41);
            this.radioPanel.Name = "radioPanel";
            this.radioPanel.Size = new System.Drawing.Size(387, 254);
            this.radioPanel.TabIndex = 2;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(42, 159);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(100, 50);
            this.pictureBox9.TabIndex = 7;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(42, 106);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(100, 50);
            this.pictureBox8.TabIndex = 6;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(42, 53);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(100, 50);
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(42, 1);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 50);
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoEllipsis = true;
            this.radioButton4.Location = new System.Drawing.Point(9, 169);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(38, 50);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoEllipsis = true;
            this.radioButton3.Location = new System.Drawing.Point(8, 107);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(31, 50);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoEllipsis = true;
            this.radioButton2.Location = new System.Drawing.Point(9, 52);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(32, 50);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoEllipsis = true;
            this.radioButton1.Location = new System.Drawing.Point(9, 1);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(34, 50);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(23, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Question:";
            // 
            // userInfo
            // 
            this.userInfo.BackgroundColor = System.Drawing.Color.White;
            this.userInfo.BackgroundGradientColor = System.Drawing.Color.White;
            this.userInfo.BackgroundGradientMode = CodeVendor.Controls.Grouper.GroupBoxGradientMode.ForwardDiagonal;
            this.userInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.userInfo.BorderColor = System.Drawing.Color.DarkGray;
            this.userInfo.BorderThickness = 1F;
            this.userInfo.Controls.Add(this.label39);
            this.userInfo.Controls.Add(this.label38);
            this.userInfo.Controls.Add(this.label1);
            this.userInfo.Controls.Add(this.label18);
            this.userInfo.Controls.Add(this.label17);
            this.userInfo.Controls.Add(this.label16);
            this.userInfo.Controls.Add(this.label15);
            this.userInfo.Controls.Add(this.label14);
            this.userInfo.Controls.Add(this.label24);
            this.userInfo.Controls.Add(this.Complexity);
            this.userInfo.Controls.Add(this.label12);
            this.userInfo.Controls.Add(this.label11);
            this.userInfo.Controls.Add(this.label10);
            this.userInfo.Controls.Add(this.label9);
            this.userInfo.Controls.Add(this.label8);
            this.userInfo.CustomGroupBoxColor = System.Drawing.Color.White;
            this.userInfo.GroupImage = null;
            this.userInfo.GroupTitle = "";
            this.userInfo.Location = new System.Drawing.Point(6, 0);
            this.userInfo.Name = "userInfo";
            this.userInfo.Padding = new System.Windows.Forms.Padding(20);
            this.userInfo.PaintGroupBox = false;
            this.userInfo.RoundCorners = 15;
            this.userInfo.ShadowColor = System.Drawing.Color.DarkGray;
            this.userInfo.ShadowControl = false;
            this.userInfo.ShadowThickness = 3;
            this.userInfo.Size = new System.Drawing.Size(672, 88);
            this.userInfo.TabIndex = 4;
            this.userInfo.TabStop = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(403, 29);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(48, 15);
            this.label39.TabIndex = 18;
            this.label39.Text = "label39";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(308, 29);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(103, 15);
            this.label38.TabIndex = 17;
            this.label38.Text = "Candidate Name:";
            // 
            // label1
            // 
            this.label1.AutoEllipsis = true;
            this.label1.Location = new System.Drawing.Point(97, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(511, 20);
            this.label1.TabIndex = 16;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(97, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 15);
            this.label18.TabIndex = 10;
            this.label18.Text = "label18";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(102, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 15);
            this.label17.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoEllipsis = true;
            this.label16.Location = new System.Drawing.Point(402, 40);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(183, 27);
            this.label16.TabIndex = 8;
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoEllipsis = true;
            this.label15.Location = new System.Drawing.Point(404, 66);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(178, 23);
            this.label15.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(97, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 15);
            this.label14.TabIndex = 6;
            this.label14.Text = "5TH";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 11);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(92, 15);
            this.label24.TabIndex = 14;
            this.label24.Text = "Question Topic:";
            // 
            // Complexity
            // 
            this.Complexity.AutoSize = true;
            this.Complexity.Location = new System.Drawing.Point(409, 58);
            this.Complexity.Name = "Complexity";
            this.Complexity.Size = new System.Drawing.Size(0, 15);
            this.Complexity.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(102, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "Current Question:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(307, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 15);
            this.label11.TabIndex = 3;
            this.label11.Text = "Time Consumed:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 15);
            this.label10.TabIndex = 2;
            this.label10.Text = "Test Duration:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(308, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "Pass Percentage:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 15);
            this.label8.TabIndex = 0;
            this.label8.Text = "Test Name:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.grouper1);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(925, 473);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Mock Test Result";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // grouper1
            // 
            this.grouper1.BackgroundColor = System.Drawing.Color.White;
            this.grouper1.BackgroundGradientColor = System.Drawing.Color.AliceBlue;
            this.grouper1.BackgroundGradientMode = CodeVendor.Controls.Grouper.GroupBoxGradientMode.BackwardDiagonal;
            this.grouper1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.grouper1.BorderColor = System.Drawing.Color.White;
            this.grouper1.BorderThickness = 1F;
            this.grouper1.Controls.Add(this.label36);
            this.grouper1.Controls.Add(this.label35);
            this.grouper1.Controls.Add(this.label6);
            this.grouper1.Controls.Add(this.label25);
            this.grouper1.Controls.Add(this.label7);
            this.grouper1.Controls.Add(this.label32);
            this.grouper1.Controls.Add(this.label26);
            this.grouper1.Controls.Add(this.label31);
            this.grouper1.Controls.Add(this.label19);
            this.grouper1.Controls.Add(this.label30);
            this.grouper1.Controls.Add(this.label29);
            this.grouper1.Controls.Add(this.label27);
            this.grouper1.Controls.Add(this.label28);
            this.grouper1.Controls.Add(this.label22);
            this.grouper1.CustomGroupBoxColor = System.Drawing.Color.Maroon;
            this.grouper1.GroupImage = null;
            this.grouper1.GroupTitle = "Test Result Summary";
            this.grouper1.Location = new System.Drawing.Point(18, 5);
            this.grouper1.Name = "grouper1";
            this.grouper1.Padding = new System.Windows.Forms.Padding(20);
            this.grouper1.PaintGroupBox = false;
            this.grouper1.RoundCorners = 15;
            this.grouper1.ShadowColor = System.Drawing.Color.DarkGray;
            this.grouper1.ShadowControl = false;
            this.grouper1.ShadowThickness = 10;
            this.grouper1.Size = new System.Drawing.Size(852, 78);
            this.grouper1.TabIndex = 18;
            this.grouper1.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(9, 25);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 15);
            this.label36.TabIndex = 16;
            this.label36.Text = "Name of the student:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(9, 53);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 15);
            this.label35.TabIndex = 17;
            this.label35.Text = "label35";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(161, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Test Name:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(161, 52);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 15);
            this.label25.TabIndex = 4;
            this.label25.Text = "label25";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(279, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "No Of Questions:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(750, 53);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 15);
            this.label32.TabIndex = 11;
            this.label32.Text = "label32";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(279, 52);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 15);
            this.label26.TabIndex = 5;
            this.label26.Text = "label26";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(638, 52);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 15);
            this.label31.TabIndex = 10;
            this.label31.Text = "label31";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(384, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "Test Duration:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(750, 25);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(71, 15);
            this.label30.TabIndex = 9;
            this.label30.Text = "Test Score :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(638, 25);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(71, 15);
            this.label29.TabIndex = 8;
            this.label29.Text = "Test Result:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(384, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 15);
            this.label27.TabIndex = 6;
            this.label27.Text = "label27";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(501, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 15);
            this.label28.TabIndex = 7;
            this.label28.Text = "label28";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(498, 25);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 15);
            this.label22.TabIndex = 3;
            this.label22.Text = "Pass Percentage:";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(18, 119);
            this.dataGridView3.Name = "dataGridView3";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView3.Size = new System.Drawing.Size(852, 303);
            this.dataGridView3.TabIndex = 13;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Maroon;
            this.label33.Location = new System.Drawing.Point(334, 86);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(156, 18);
            this.label33.TabIndex = 12;
            this.label33.Text = "Test Result Details ";
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = global::KnowledgeMatrix.Properties.Resources.Done_75X23;
            this.button5.Location = new System.Drawing.Point(795, 432);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 15;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = global::KnowledgeMatrix.Properties.Resources.Print_75X23;
            this.button4.Location = new System.Drawing.Point(547, 432);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 14;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "MT_attempted.png");
            this.imageList1.Images.SetKeyName(1, "MT_markforreview1.png");
            this.imageList1.Images.SetKeyName(2, "MT_notattempted1.png");
            this.imageList1.Images.SetKeyName(3, "MT_skipped1.png");
            // 
            // MockTestHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Name = "MockTestHome";
            this.Size = new System.Drawing.Size(960, 510);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.checkboxPanel.ResumeLayout(false);
            this.AnswerInfo.ResumeLayout(false);
            this.AnswerInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.radioPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.userInfo.ResumeLayout(false);
            this.userInfo.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.grouper1.ResumeLayout(false);
            this.grouper1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private CodeVendor.Controls.Grouper userInfo;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label Complexity;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private CodeVendor.Controls.Grouper groupBox2;
        internal ExtendedRichTextBox.RichTextBoxPrintCtrl richTextBoxPrintCtrl7;
        internal ExtendedRichTextBox.RichTextBoxPrintCtrl richTextBoxPrintCtrl1;
        internal ExtendedRichTextBox.RichTextBoxPrintCtrl richTextBoxPrintCtrl6;
        internal ExtendedRichTextBox.RichTextBoxPrintCtrl richTextBoxPrintCtrl5;
        internal ExtendedRichTextBox.RichTextBoxPrintCtrl richTextBoxPrintCtrl4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Answer;
        private CodeVendor.Controls.Grouper AnswerInfo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Panel radioPanel;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label20;
        private CodeVendor.Controls.Grouper groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Last;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button Previous;
        private System.Windows.Forms.Panel checkboxPanel;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private CodeVendor.Controls.Grouper grouper1;
        private System.Windows.Forms.Button First;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel pnlShanuGrid;

    }
}
