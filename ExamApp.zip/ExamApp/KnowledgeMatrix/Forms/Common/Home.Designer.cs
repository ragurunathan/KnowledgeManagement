﻿namespace KnowledgeMatrix
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Help = new System.Windows.Forms.Button();
            this.Report = new System.Windows.Forms.Button();
            this.License = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dashboardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTutorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questionBankToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questionPaperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mockTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.licenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productPurchasingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mockTestToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutKnowledgeMatrixToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Test = new System.Windows.Forms.Button();
            this.QuestionPaper = new System.Windows.Forms.Button();
            this.QuestionBank = new System.Windows.Forms.Button();
            this.eTutor = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblFooter = new System.Windows.Forms.Label();
            this.Header = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblHeader = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.Header.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(0, 110);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(914, 505);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.Test);
            this.panel2.Controls.Add(this.QuestionPaper);
            this.panel2.Controls.Add(this.QuestionBank);
            this.panel2.Controls.Add(this.eTutor);
            this.panel2.Location = new System.Drawing.Point(-7, 37);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(922, 73);
            this.panel2.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.toolStrip1);
            this.panel5.Location = new System.Drawing.Point(14, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(908, 42);
            this.panel5.TabIndex = 13;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.pasteToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(908, 42);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::KnowledgeMatrix.Properties.Resources.dash_board;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(32, 39);
            this.toolStripButton1.Tag = "Dashboard";
            this.toolStripButton1.Text = "Dashboard";
            this.toolStripButton1.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Tutuor;
            this.newToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(32, 39);
            this.newToolStripButton.Tag = "eTutor";
            this.newToolStripButton.Text = "Knowledge &Tutor";
            this.newToolStripButton.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Base1;
            this.openToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(32, 39);
            this.openToolStripButton.Tag = "QuestionBank";
            this.openToolStripButton.Text = "Knowledge &Base";
            this.openToolStripButton.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Assesment_ico;
            this.saveToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(32, 39);
            this.saveToolStripButton.Tag = "QuestionPaper";
            this.saveToolStripButton.Text = "Knowledge &Assessment";
            this.saveToolStripButton.ToolTipText = "Knowledge Assessment";
            this.saveToolStripButton.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Evalutor;
            this.pasteToolStripButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(32, 39);
            this.pasteToolStripButton.Tag = "MockTestHome";
            this.pasteToolStripButton.Text = "Knowledge &Evaluator";
            this.pasteToolStripButton.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.Help);
            this.panel4.Controls.Add(this.Report);
            this.panel4.Controls.Add(this.License);
            this.panel4.Controls.Add(this.Home);
            this.panel4.Controls.Add(this.menuStrip1);
            this.panel4.Location = new System.Drawing.Point(0, 1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(919, 26);
            this.panel4.TabIndex = 12;
            // 
            // Help
            // 
            this.Help.Enabled = false;
            this.Help.Location = new System.Drawing.Point(726, 3);
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(78, 21);
            this.Help.TabIndex = 8;
            this.Help.Text = "Help";
            this.Help.UseVisualStyleBackColor = true;
            this.Help.Visible = false;
            this.Help.Click += new System.EventHandler(this.Help_Click);
            // 
            // Report
            // 
            this.Report.Enabled = false;
            this.Report.Location = new System.Drawing.Point(642, 3);
            this.Report.Name = "Report";
            this.Report.Size = new System.Drawing.Size(78, 21);
            this.Report.TabIndex = 7;
            this.Report.Text = "Report";
            this.Report.UseVisualStyleBackColor = true;
            this.Report.Visible = false;
            // 
            // License
            // 
            this.License.Enabled = false;
            this.License.Location = new System.Drawing.Point(567, 3);
            this.License.Name = "License";
            this.License.Size = new System.Drawing.Size(78, 21);
            this.License.TabIndex = 6;
            this.License.Text = "License";
            this.License.UseVisualStyleBackColor = true;
            this.License.Visible = false;
            // 
            // Home
            // 
            this.Home.Location = new System.Drawing.Point(492, 3);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(78, 21);
            this.Home.TabIndex = 5;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Visible = false;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem1,
            this.homeToolStripMenuItem,
            this.licenseToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(917, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem1
            // 
            this.homeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.homeToolStripMenuItem1.Name = "homeToolStripMenuItem1";
            this.homeToolStripMenuItem1.Size = new System.Drawing.Size(52, 20);
            this.homeToolStripMenuItem1.Text = "Home";
            // 
            // dashboardToolStripMenuItem1
            // 
            this.dashboardToolStripMenuItem1.Name = "dashboardToolStripMenuItem1";
            this.dashboardToolStripMenuItem1.Size = new System.Drawing.Size(134, 22);
            this.dashboardToolStripMenuItem1.Tag = "Dashboard";
            this.dashboardToolStripMenuItem1.Text = "Dash Board";
            this.dashboardToolStripMenuItem1.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eTutorToolStripMenuItem,
            this.questionBankToolStripMenuItem,
            this.questionPaperToolStripMenuItem,
            this.mockTestToolStripMenuItem});
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.H)));
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.homeToolStripMenuItem.Text = "Products";
            // 
            // eTutorToolStripMenuItem
            // 
            this.eTutorToolStripMenuItem.Name = "eTutorToolStripMenuItem";
            this.eTutorToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.T)));
            this.eTutorToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.eTutorToolStripMenuItem.Tag = "eTutor";
            this.eTutorToolStripMenuItem.Text = "Knowledge Tutor";
            this.eTutorToolStripMenuItem.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // questionBankToolStripMenuItem
            // 
            this.questionBankToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.editToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.questionBankToolStripMenuItem.Name = "questionBankToolStripMenuItem";
            this.questionBankToolStripMenuItem.ShowShortcutKeys = false;
            this.questionBankToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.questionBankToolStripMenuItem.Tag = "QuestionBank";
            this.questionBankToolStripMenuItem.Text = "Knowledge Base";
            this.questionBankToolStripMenuItem.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D)));
            this.addToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.addToolStripMenuItem.Text = "Add Questions";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.editToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.editToolStripMenuItem.Text = "Edit Questions";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.ShortcutKeyDisplayString = "Alt+D";
            this.deleteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.deleteToolStripMenuItem.Text = "Delete Questions";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // questionPaperToolStripMenuItem
            // 
            this.questionPaperToolStripMenuItem.Name = "questionPaperToolStripMenuItem";
            this.questionPaperToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.A)));
            this.questionPaperToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.questionPaperToolStripMenuItem.Tag = "QuestionPaper";
            this.questionPaperToolStripMenuItem.Text = "Knowledge Assessment ";
            this.questionPaperToolStripMenuItem.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // mockTestToolStripMenuItem
            // 
            this.mockTestToolStripMenuItem.Name = "mockTestToolStripMenuItem";
            this.mockTestToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.E)));
            this.mockTestToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.mockTestToolStripMenuItem.Tag = "MockTestHome";
            this.mockTestToolStripMenuItem.Text = "Knowledge Evaluator";
            this.mockTestToolStripMenuItem.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // licenseToolStripMenuItem
            // 
            this.licenseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productKeyToolStripMenuItem,
            this.productPurchasingToolStripMenuItem});
            this.licenseToolStripMenuItem.Name = "licenseToolStripMenuItem";
            this.licenseToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.licenseToolStripMenuItem.Text = "License";
            // 
            // productKeyToolStripMenuItem
            // 
            this.productKeyToolStripMenuItem.Name = "productKeyToolStripMenuItem";
            this.productKeyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.K)));
            this.productKeyToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.productKeyToolStripMenuItem.Tag = "LicenseManagement";
            this.productKeyToolStripMenuItem.Text = "Product Key";
            this.productKeyToolStripMenuItem.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // productPurchasingToolStripMenuItem
            // 
            this.productPurchasingToolStripMenuItem.Name = "productPurchasingToolStripMenuItem";
            this.productPurchasingToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.productPurchasingToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.P)));
            this.productPurchasingToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.productPurchasingToolStripMenuItem.Tag = "PurchaseManagement";
            this.productPurchasingToolStripMenuItem.Text = "Product Purchasing";
            this.productPurchasingToolStripMenuItem.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mockTestToolStripMenuItem1});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // mockTestToolStripMenuItem1
            // 
            this.mockTestToolStripMenuItem1.Name = "mockTestToolStripMenuItem1";
            this.mockTestToolStripMenuItem1.Size = new System.Drawing.Size(185, 22);
            this.mockTestToolStripMenuItem1.Tag = "ChartMaster";
            this.mockTestToolStripMenuItem1.Text = "Knowledge Evaluator";
            this.mockTestToolStripMenuItem1.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutKnowledgeMatrixToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutKnowledgeMatrixToolStripMenuItem
            // 
            this.aboutKnowledgeMatrixToolStripMenuItem.Name = "aboutKnowledgeMatrixToolStripMenuItem";
            this.aboutKnowledgeMatrixToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.aboutKnowledgeMatrixToolStripMenuItem.Text = "About Knowledge Matrix";
            this.aboutKnowledgeMatrixToolStripMenuItem.Click += new System.EventHandler(this.aboutKnowledgeMatrixToolStripMenuItem_Click);
            // 
            // Test
            // 
            this.Test.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Test.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Test.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Assesment_ico;
            this.Test.Location = new System.Drawing.Point(562, 27);
            this.Test.Name = "Test";
            this.Test.Size = new System.Drawing.Size(75, 23);
            this.Test.TabIndex = 11;
            this.Test.Tag = "Test";
            this.Test.UseVisualStyleBackColor = true;
            this.Test.Visible = false;
            this.Test.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // QuestionPaper
            // 
            this.QuestionPaper.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.QuestionPaper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QuestionPaper.ForeColor = System.Drawing.Color.White;
            this.QuestionPaper.Location = new System.Drawing.Point(472, 26);
            this.QuestionPaper.Name = "QuestionPaper";
            this.QuestionPaper.Size = new System.Drawing.Size(75, 27);
            this.QuestionPaper.TabIndex = 10;
            this.QuestionPaper.Tag = "QuestionPaper";
            this.QuestionPaper.Text = "Question Paper";
            this.QuestionPaper.UseVisualStyleBackColor = false;
            this.QuestionPaper.Visible = false;
            this.QuestionPaper.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // QuestionBank
            // 
            this.QuestionBank.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.QuestionBank.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QuestionBank.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Base1;
            this.QuestionBank.Location = new System.Drawing.Point(385, 26);
            this.QuestionBank.Name = "QuestionBank";
            this.QuestionBank.Size = new System.Drawing.Size(75, 27);
            this.QuestionBank.TabIndex = 9;
            this.QuestionBank.Tag = "QuestionBank";
            this.QuestionBank.UseVisualStyleBackColor = true;
            this.QuestionBank.Visible = false;
            this.QuestionBank.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // eTutor
            // 
            this.eTutor.BackColor = System.Drawing.SystemColors.Desktop;
            this.eTutor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.eTutor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eTutor.ForeColor = System.Drawing.Color.White;
            this.eTutor.Image = global::KnowledgeMatrix.Properties.Resources.Knowledge_Tutuor;
            this.eTutor.Location = new System.Drawing.Point(301, 26);
            this.eTutor.Name = "eTutor";
            this.eTutor.Size = new System.Drawing.Size(75, 27);
            this.eTutor.TabIndex = 8;
            this.eTutor.Tag = "eTutor";
            this.eTutor.UseVisualStyleBackColor = false;
            this.eTutor.Visible = false;
            this.eTutor.Click += new System.EventHandler(this.eTutor_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pictureBox1);
            this.panel6.Location = new System.Drawing.Point(1, 38);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(917, 71);
            this.panel6.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.PowderBlue;
            this.pictureBox1.BackgroundImage = global::KnowledgeMatrix.Properties.Resources.Web_banner;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::KnowledgeMatrix.Properties.Resources.Web_banner;
            this.pictureBox1.InitialImage = global::KnowledgeMatrix.Properties.Resources.Web_banner;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(914, 72);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "KM Header.png");
            this.imageList1.Images.SetKeyName(1, "KM HeaderOne.png");
            this.imageList1.Images.SetKeyName(2, "KM HeaderTwo.png");
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(27)))), ((int)(((byte)(66)))));
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.lblFooter);
            this.panel3.Location = new System.Drawing.Point(-4, 615);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(926, 27);
            this.panel3.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            this.label2.Location = new System.Drawing.Point(33, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 19);
            this.label2.TabIndex = 2;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            this.label1.Location = new System.Drawing.Point(630, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 14);
            this.label1.TabIndex = 1;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFooter
            // 
            this.lblFooter.AutoSize = true;
            this.lblFooter.BackColor = System.Drawing.Color.Transparent;
            this.lblFooter.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFooter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            this.lblFooter.Location = new System.Drawing.Point(296, 2);
            this.lblFooter.Name = "lblFooter";
            this.lblFooter.Size = new System.Drawing.Size(111, 19);
            this.lblFooter.TabIndex = 0;
            this.lblFooter.Text = "Digital Warriors";
            this.lblFooter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Header
            // 
            this.Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(27)))), ((int)(((byte)(66)))));
            this.Header.Controls.Add(this.button2);
            this.Header.Controls.Add(this.button1);
            this.Header.Controls.Add(this.label3);
            this.Header.Controls.Add(this.lblHeader);
            this.Header.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.Header.Location = new System.Drawing.Point(-4, -8);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(933, 49);
            this.Header.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.LightBlue;
            this.button2.Image = global::KnowledgeMatrix.Properties.Resources.About;
            this.button2.Location = new System.Drawing.Point(832, 14);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 25);
            this.button2.TabIndex = 3;
            this.button2.Tag = "eTutor";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Image = global::KnowledgeMatrix.Properties.Resources.About;
            this.button1.Location = new System.Drawing.Point(834, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 27);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(831, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 14);
            this.label3.TabIndex = 1;
            this.label3.Text = "Digital Warriors";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Visible = false;
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.Transparent;
            this.lblHeader.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            this.lblHeader.Location = new System.Drawing.Point(20, 8);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(0, 33);
            this.lblHeader.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 642);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Header);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KNOWLEDGE MATRIX";
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Header.ResumeLayout(false);
            this.Header.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Header;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblFooter;
        private System.Windows.Forms.Button eTutor;
        private System.Windows.Forms.Button QuestionBank;
        private System.Windows.Forms.Button QuestionPaper;
        private System.Windows.Forms.Button Test;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button License;
        private System.Windows.Forms.Button Report;
        private System.Windows.Forms.Button Help;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem licenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTutorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questionBankToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questionPaperToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mockTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productKeyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productPurchasingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem aboutKnowledgeMatrixToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem mockTestToolStripMenuItem1;
    }
}

