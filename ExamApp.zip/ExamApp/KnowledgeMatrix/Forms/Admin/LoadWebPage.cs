﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KnowledgeMatrix.Forms.Admin
{
    public partial class LoadWebPage : UserControl
    {
        public LoadWebPage()
        {
            InitializeComponent();
        }

        private void LoadWebPage_Load(object sender, EventArgs e)
        {

        }

    }
}
