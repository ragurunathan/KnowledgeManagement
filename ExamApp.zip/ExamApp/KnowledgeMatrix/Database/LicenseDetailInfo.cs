﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KnowledgeMatrix.Database
{
    public class LicenseDetailInfo
    {
        public string ProductName;
        public string ProductType;
        public string DateOfPurchase;
        public string DateOfExpiry;
        public int LicenseMasterID;
        public string IP;
    }
}
