﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Knowledge Matrix")]
[assembly: AssemblyDescription(@"  i.      Knowledge Matrix Products suit is the  new way of learning and  assessment tool for Academy Students and Professionals 

ii.      The Suits comprise of 

    1.       Knowledge Tutor – A Digital Flash card based product to learn the concepts and memorize the important points , formulas , notes etc. 

    2.       Knowledge Base – A Digital Question Bank Product to practice the lesson learnt , concepts , concepts and understandings in the forms of questions and answers 

    3.       Knowledge Evaluator – A Digital  offline Mock  Test Product to self-evaluate the lesson learnt in the form of Mock test 

    4.       Knowledge Assessment – A Digital Question Paper Generator to Prepare and Generate Question and Exam in the form of Traditional Paper based to create and replicate real exams ")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Knowledge Matrix")]
[assembly: AssemblyCopyright("Copyright © Digital Warriors 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d279ee3c-4963-49eb-a512-839498b0434a")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
